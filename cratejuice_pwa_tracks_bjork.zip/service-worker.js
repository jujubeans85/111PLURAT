const CACHE_NAME="cratejuice-v1";
const ASSETS=["./","./index.html","./style.css","./app.js","./manifest.json","./icon.png",
"./tracks/01_lofi_nights.mp3","./tracks/02_dreamscape_drift.mp3","./tracks/03_soft_pulse.mp3",
"./tracks/04_acoustic_breeze.mp3","./tracks/05_bjork_all_is_full_of_love_remix.mp3"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(ASSETS)))});
self.addEventListener("activate",e=>{e.waitUntil(self.clients.claim())});
self.addEventListener("fetch",e=>{e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)))})