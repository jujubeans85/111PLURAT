# CrateJuice Frontend — Vintage Skin + Add Track Modal

- 1200s-style deck (CSS platter, label, dots, tonearm)
- VU meter (WebAudio analyser, falls back gracefully)
- Add Track modal (stores custom tracks in localStorage)
- Netlify proxy for `/api/*` → `https://api.cratejuice.org`

## Deploy
Drag-drop to Netlify or connect a repo. Ensure your backend is live under the API subdomain.

## Notes
- Direct audio only (mp3/wav/ogg URLs) will play in the in-page player. External platforms open via the QR/Link.
- Your saved tracks persist in the browser via localStorage.
