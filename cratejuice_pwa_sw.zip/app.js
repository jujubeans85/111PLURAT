function playSample(){
  const a=document.getElementById('player');
  a.src='sample.mp3';
  a.play().catch(console.warn);
}