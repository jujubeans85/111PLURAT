// postcard.js — generates a QR to a CrateJuice deep link and shows an optional quote.
// Params: t=<slug> (required), q=<quote>, from=<name>, style=<vintage|clean|neon>, base=<override base URL>
(function(){
  const params = new URLSearchParams(location.search);
  const slug = params.get('t') || 'mimis-drift';
  const quote = params.get('q');
  const from = params.get('from');
  const style = (params.get('style')||'vintage').toLowerCase();
  const base = params.get('base') || (location.origin.includes('netlify') ? location.origin.replace(/\/postcard.*$/,'').replace(/\/$/,'') : location.origin);
  const deep = `${base}/?t=${encodeURIComponent(slug)}`;

  const styleSel = document.getElementById('styleSel');
  styleSel.value = style;
  setTheme(style);

  document.getElementById('title').textContent = 'Sonic Postcard';
  document.getElementById('desc').textContent = `Track: ${slug}`;
  const openLink = document.getElementById('openLink');
  openLink.href = deep;
  openLink.target = '_blank';

  new QRCode(document.getElementById('qrcode'), {
    text: deep,
    width: 220, height: 220, correctLevel: QRCode.CorrectLevel.H
  });

  const quoteBox = document.getElementById('quoteBox');
  if (quote) {
    document.getElementById('quoteText').textContent = decodeURIComponent(quote);
    document.getElementById('quoteFrom').textContent = from ? `— ${from}` : '';
    quoteBox.hidden = false;
  }

  document.getElementById('copyBtn').onclick = async () => {
    try{
      await navigator.clipboard.writeText(deep);
      document.getElementById('copyBtn').textContent = 'Copied!';
      setTimeout(()=>document.getElementById('copyBtn').textContent='Copy Link', 1200);
    }catch(e){
      prompt('Copy link:', deep);
    }
  };

  styleSel.onchange = () => setTheme(styleSel.value);

  function setTheme(name){
    document.body.classList.remove('theme-vintage','theme-clean','theme-neon');
    document.body.classList.add('theme-' + (name||'vintage'));
  }
})();