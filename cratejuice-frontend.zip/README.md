# CrateJuice Frontend (Netlify)

Static starter wired to `api.cratejuice.org` via Netlify proxy.

## Deploy
1. Drag-drop this folder to Netlify (or push to Git + connect).
2. Ensure your backend is live at `api.cratejuice.org`.
3. Done: open your Netlify URL or hook your domain `cratejuice.org`.

## Notes
- Update `tracks.json` with your own URLs (self-hosted files work best).
- Direct playback of Spotify/YouTube isn't supported by `<audio>`; for those use embeds or cache your own preview clips.
