// Config
const API_BASE = '/api'; // Netlify will proxy this to https://api.cratejuice.org

const player = document.getElementById('player');
const playBtn = document.getElementById('playBtn');
const pauseBtn = document.getElementById('pauseBtn');
const vol = document.getElementById('vol');
const pitch = document.getElementById('pitch');
const vu = document.getElementById('vu');
const trackListEl = document.getElementById('trackList');
const recentListEl = document.getElementById('recentList');
const trackTitle = document.getElementById('trackTitle');
const trackSource = document.getElementById('trackSource');
const art = document.getElementById('art');
const qrLink = document.getElementById('qrLink');
const userSel = document.getElementById('userSel');
const memo = document.getElementById('memo');

let current = null;
let vuTimer = null;

// Load seed tracks
fetch('tracks.json').then(r=>r.json()).then(data => {
  data.forEach((t, idx) => addTrackRow(t, idx));
  if (data[0]) selectTrack(data[0], false);
});

function addTrackRow(t, idx){
  const li = document.createElement('li');
  const left = document.createElement('div');
  const right = document.createElement('div');
  left.innerHTML = `<strong>${t.title}</strong> <small>· ${t.source || 'file/URL'}</small>`;
  const btn = document.createElement('button');
  btn.className = 'track-btn';
  btn.textContent = 'Load';
  btn.onclick = () => selectTrack(t, true);
  right.appendChild(btn);
  li.appendChild(left); li.appendChild(right);
  trackListEl.appendChild(li);
}

function selectTrack(t, autostart){
  current = t;
  player.src = t.url;
  trackTitle.textContent = t.title || '—';
  trackSource.textContent = t.source ? `source: ${t.source}` : 'source: file/URL';
  art.style.backgroundImage = t.art ? `url('${t.art}')` : '';
  art.style.backgroundSize = 'cover';
  qrLink.href = t.url;
  if (autostart) { player.play(); }
}

playBtn.onclick = async () => {
  try {
    await player.play();
    logPlay();
  } catch (e){
    console.error('play failed', e);
  }
};

pauseBtn.onclick = () => player.pause();
vol.oninput = () => player.volume = parseFloat(vol.value);
pitch.oninput = () => player.playbackRate = parseFloat(pitch.value);

// Fake VU meter pulse based on audio timeupdate
player.addEventListener('timeupdate', () => {
  const level = Math.round((Math.sin(player.currentTime*6)+1)*50);
  vu.textContent = 'VU ' + '█'.repeat(Math.max(1, level/10));
});

async function logPlay(){
  if (!current) return;
  const payload = {
    track_id: current.url || current.title,
    source: current.source || 'file',
    user: userSel.value || 'guest',
    memo: memo.value || undefined
  };
  try {
    await fetch(`${API_BASE}/tracks/log`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload)
    });
    loadRecent();
  } catch (e){
    console.warn('log failed (okay if API not live yet)', e);
  }
}

async function loadRecent(){
  try {
    const r = await fetch(`${API_BASE}/tracks/recent?limit=10`);
    const data = await r.json();
    recentListEl.innerHTML = '';
    data.forEach(item => {
      const li = document.createElement('li');
      const when = new Date(item.played_at).toLocaleString();
      li.innerHTML = `<div><strong>${item.track_id}</strong> <small>· ${item.source||''}</small></div><div>${when}</div>`;
      recentListEl.appendChild(li);
    });
  } catch(e){
    // ignore if backend not live
  }
}

// initial recent
loadRecent();
